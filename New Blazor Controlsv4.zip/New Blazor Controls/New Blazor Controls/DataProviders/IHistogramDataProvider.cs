using System.Collections.Generic;
using System.Threading.Tasks;
using New_Blazor_Controls.Data;

namespace New_Blazor_Controls.DataProviders {
    public interface IHistogramDataProvider {
        public Task<IEnumerable<DataPoint>> GetNormalDistribution();
        public Task<IEnumerable<DataPoint>> GenerateData();
    }
}
