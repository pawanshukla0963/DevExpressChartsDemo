﻿using DevExpress.Blazor;
using New_Blazor_Controls.Data;
using New_Blazor_Controls.DataProviders;
using New_Blazor_Controls.Pages;
using DevExpress.Data;
using System.Drawing;



namespace New_Blazor_Controls.Pages
{

    public partial class BlazorCharts
    {
        //code behind for chart export control
        DxChartBase chart;
        void Export(MenuItemClickEventArgs args)
        {
            ChartExportFormat format = ChartExportFormat.Png;
            Color backgroundColor = Color.White;
            int margin = 4;
            if (Enum.TryParse<ChartExportFormat>(args.ItemInfo.Text, true, out format))
                chart?.ExportAsync("Exported_Chart", format, margin, backgroundColor);
        }


        //to select different chart types
        protected bool Series1Visible { get; set; } = true;
        protected bool Series2Visible { get; set; } = true;
        protected bool Series3Visible { get; set; } = true;
        protected bool Series4Visible { get; set; } = true;


        Dictionary<string, bool> seriesVisibleState = new Dictionary<string, bool>();
        Action<bool> GetVisibleChangeHandler(string seriesName)
        {
            return (visible) => seriesVisibleState[seriesName] = visible;
        }


        //bp data
        private BloodPressure[] bptracker;

        //to fetch below obj data in chart on pageload
        protected override void OnInitialized()
        {
            bptracker = GetDailyBP();
            weighttracker = GetDailyWeight();
        }


        public class BloodPressure
        {
            public DateTime Date { get; set; }
            public int BPSystolic { get; set; }
            public double Diastolic { get; set; }
        }

        public BloodPressure[] GetDailyBP()
        {
            BloodPressure[] bptracker = new BloodPressure[] {
                new BloodPressure() { Date = new DateTime(2020, 05, 11), BPSystolic = 20,
                                        Diastolic = 5},
                new BloodPressure() { Date = new DateTime(2020, 05, 12), BPSystolic = 22,
                                        Diastolic = 1.2},
                new BloodPressure() { Date = new DateTime(2020, 05, 13), BPSystolic = 18,
                                        Diastolic = 0.8},
                new BloodPressure() { Date = new DateTime(2020, 05, 14), BPSystolic = 19,
                                        Diastolic = 0},
                new BloodPressure() { Date = new DateTime(2020, 05, 15), BPSystolic = 14,
                                        Diastolic = 3.3},
                new BloodPressure() { Date = new DateTime(2020, 05, 16), BPSystolic = 15,
                                        Diastolic = 1.7},
                new BloodPressure() { Date = new DateTime(2020, 05, 17), BPSystolic = 18,
                                        Diastolic = 1},
                new BloodPressure() { Date = new DateTime(2020, 05, 18), BPSystolic = 10,
                                        Diastolic = 0},
                new BloodPressure() { Date = new DateTime(2020, 05, 19), BPSystolic = 21,
                                        Diastolic = 4.4},
                new BloodPressure() { Date = new DateTime(2020, 05, 20), BPSystolic = 20,
                                        Diastolic = 8.5},
    };
            return bptracker;
        }



        //weight data

        private Weight[] weighttracker;


        public class Weight
        {
            public DateTime Date { get; set; }
            public int Weighti { get; set; }

        }

        public Weight[] GetDailyWeight()
        {
            Weight[] weighttracker = new Weight[] {
                new Weight() { Date = new DateTime(2020, 05, 11), Weighti = 60,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 12), Weighti = 62,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 13), Weighti = 58,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 14), Weighti = 65,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 15), Weighti = 59,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 16), Weighti = 70,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 17), Weighti = 72,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 18), Weighti = 78,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 19), Weighti = 65,
                                        },
                new Weight() { Date = new DateTime(2020, 05, 20), Weighti = 68,
                                        },
    };
            return weighttracker;
        }


        //histogram dataprovider
        double interval = 1;
        DxChart histogramChart;
        IEnumerable<DataPoint> NormalDistribution { get; set; }
        IEnumerable<DataPoint> GeneratedData { get; set; }
        double Interval
        {
            get => interval;
            set
            {
                if (interval != value)
                {
                    interval = value;
                    histogramChart?.RefreshData();
                }
            }
        }
        string GeneratedDataSeriesName = "Generated Data";
        


        //rangebarchart dataprovider
        WeatherForecastRB[] ChartData;


        //async function to fetch histo n rangebar data obj
        protected override async Task OnInitializedAsync()
        {
            //histogram data
            NormalDistribution = await DataProvider.GetNormalDistribution();
            GeneratedData = await DataProvider.GenerateData();

            //rangebar data
            ChartData = await ForecastService.GetRangeForecastAsync();
        }
    }
}
