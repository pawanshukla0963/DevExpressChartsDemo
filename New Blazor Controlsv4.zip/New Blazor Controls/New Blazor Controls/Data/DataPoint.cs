using System;
using System.Runtime.InteropServices;

namespace New_Blazor_Controls.Data {
    
    public class DataPoint {
        public double X { get; }
        public double Y { get; }

        public DataPoint(double x, double y) {
            X = x;
            Y = y;
        }
    }
}
