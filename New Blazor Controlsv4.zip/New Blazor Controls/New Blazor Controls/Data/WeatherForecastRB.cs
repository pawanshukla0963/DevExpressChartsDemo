﻿//namespace ChartBlazorApp1.Data
//{
//    public class WeatherForecastServiceRB
//    {
//    }
//}

using System;
namespace New_Blazor_Controls.Data
{
    public class WeatherForecastRB
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public double TemperatureF => Math.Round((TemperatureC * 1.8 + 32), 2);
        public double Precipitation { get; set; }

        //public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        //public string? Summary { get; set; }
    }
}