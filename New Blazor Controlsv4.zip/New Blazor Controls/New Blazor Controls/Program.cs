using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using New_Blazor_Controls.Data;
using New_Blazor_Controls.DataProviders;
using DevExpress.Blazor;
using DevExpress.Data;
using New_Blazor_Controls.DataProviders.Implementation;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//gen devexpress components
builder.Services.AddDevExpressBlazor(configure => configure.BootstrapVersion = BootstrapVersion.v5);
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddSingleton<WeatherForecastService>();

//histogram service register
builder.Services.AddSingleton<IHistogramDataProvider, HistogramDataProvider>();

//rangebar service register
builder.Services.AddSingleton<WeatherForecastServiceRB>();

builder.Services.AddDevExpressBlazor();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
